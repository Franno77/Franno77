def multiply_int(num: int, multiplier: int) -> int:
    multiplied_num = num * multiplier
    return multiplied_num
