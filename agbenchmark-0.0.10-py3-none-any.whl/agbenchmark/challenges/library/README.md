This is the official library for user submitted challenges.
